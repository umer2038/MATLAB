%% Genetic Algorithm for Human Pose Optimization
clear all; close all; clc;

%% Load Data
try
    load('GTPose.mat');           % Contains queryPose
    load('datasetPoses.mat');     % Contains datasetPoses
    disp('Data loaded successfully.');
catch
    error('Error loading data files. Make sure GTPose.mat and datasetPoses.mat are in the current directory.');
end

GTPose = queryPose;
PopulationPoses = datasetPoses;

fprintf('Ground Truth Pose dimension: %d x %d\n', size(GTPose));
fprintf('Population Poses dimension: %d x %d\n', size(PopulationPoses));

%% GA Parameters
params.populationSize = min(size(PopulationPoses, 2), 100);
params.maxGenerations = 100;
params.crossoverProbability = 0.8;
params.mutationProbability = 0.1;
params.eliteCount = 5;
params.tournamentSize = 5;

%% Initialization
population = PopulationPoses;
[dim, populationSize] = size(population);
params.populationSize = populationSize;

numJoints = size(GTPose, 1) / 3;
if mod(numJoints, 1) ~= 0
    error('GTPose must be divisible by 3.');
end
numJoints = floor(numJoints);

bestFitness = zeros(params.maxGenerations, 1);
meanFitness = zeros(params.maxGenerations, 1);
bestPose = zeros(params.maxGenerations, dim);
metrics_history = struct('MJPE', zeros(params.maxGenerations, 1), ...
                         'PCK', zeros(params.maxGenerations, 1), ...
                         'PEA', zeros(params.maxGenerations, 1));

tic;

%% Genetic Algorithm Loop
fprintf('\n===== Starting Genetic Algorithm =====\n');
fitness = evaluateFitness(population, GTPose);
[bestFitVal, bestIdx] = min(fitness);
bestPose(1, :) = population(:, bestIdx)';
bestFitness(1) = bestFitVal;
meanFitness(1) = mean(fitness);

metrics = calculateMetrics(population(:, bestIdx), GTPose);
metrics_history.MJPE(1) = metrics.MJPE;
metrics_history.PCK(1) = metrics.PCK;
metrics_history.PEA(1) = metrics.PEA;

fprintf('Initial Best Fitness: %.4f\n', bestFitVal);

for generation = 2:params.maxGenerations
    parents = selection(population, fitness, params);
    offspring = crossover(parents, params);
    offspring = mutation(offspring, params);

    [~, eliteIndices] = sort(fitness);
    elite = population(:, eliteIndices(1:params.eliteCount));
    population = [elite, offspring(:, 1:(populationSize - params.eliteCount))];

    fitness = evaluateFitness(population, GTPose);
    [bestFitVal, bestIdx] = min(fitness);
    bestPose(generation, :) = population(:, bestIdx)';
    bestFitness(generation) = bestFitVal;
    meanFitness(generation) = mean(fitness);

    metrics = calculateMetrics(population(:, bestIdx), GTPose);
    metrics_history.MJPE(generation) = metrics.MJPE;
    metrics_history.PCK(generation) = metrics.PCK;
    metrics_history.PEA(generation) = metrics.PEA;

    if mod(generation, 10) == 0 || generation == params.maxGenerations
        fprintf('Generation %d: Best = %.4f, Mean = %.4f\n', ...
            generation, bestFitness(generation), meanFitness(generation));
    end
end

executionTime = toc;

%% Final Results
[finalBestFitness, bestGeneration] = min(bestFitness);
finalBestPose = bestPose(bestGeneration, :)';
finalMetrics = calculateMetrics(finalBestPose, GTPose);

fprintf('\n===== Final Results =====\n');
fprintf('Best Generation: %d\n', bestGeneration);
fprintf('Best Fitness: %.4f\n', finalBestFitness);
fprintf('MJPE: %.4f, PCK: %.2f%%, PEA: %.4f\n', ...
        finalMetrics.MJPE, finalMetrics.PCK*100, finalMetrics.PEA);

%% Plotting
figure;
subplot(2,1,1);
plot(bestFitness, 'b-', 'LineWidth', 2); hold on;
plot(meanFitness, 'r--', 'LineWidth', 1);
xlabel('Generation'); ylabel('Fitness');
legend('Best', 'Mean'); title('Fitness Convergence'); grid on;

subplot(2,1,2);
plot(metrics_history.MJPE, 'b'); hold on;
plot(metrics_history.PCK, 'r');
plot(metrics_history.PEA / 10, 'g'); % Scaled for visibility
legend('MJPE', 'PCK', 'PEA/10'); title('Metrics Over Generations'); grid on;

figure;
visualizePoses(finalBestPose, GTPose, 'Best Pose vs Ground Truth');

save('GA_Results.mat', 'finalBestPose', 'bestFitness', 'meanFitness', ...
     'metrics_history', 'executionTime', 'finalMetrics', 'params');

%% ========== Helper Functions ==========

function fitness = evaluateFitness(population, GTpose)
    [dim, N] = size(population);
    numJoints = size(GTpose, 1) / 3;
    fitness = zeros(1, N);
    for i = 1:N
        pose = reshape(population(:, i), 3, []);
        gt = reshape(GTpose, 3, []);
        jointDistances = sqrt(sum((pose - gt).^2, 1));
        fitness(i) = sum(jointDistances.^2);
    end
end

function parents = selection(population, fitness, params)
    [dim, N] = size(population);
    parents = zeros(size(population));
    for i = 1:N
        candidates = randperm(N, params.tournamentSize);
        [~, bestIdx] = min(fitness(candidates));
        winner = candidates(bestIdx);
        parents(:, i) = population(:, winner);
    end
end

function offspring = crossover(parents, params)
    [dim, N] = size(parents);
    offspring = parents;
    for i = 1:2:N-1
        if rand < params.crossoverProbability
            points = sort(randperm(dim, 2));
            offspring(points(1):points(2), i) = parents(points(1):points(2), i+1);
            offspring(points(1):points(2), i+1) = parents(points(1):points(2), i);
        end
    end
end

function offspring = mutation(offspring, params)
    [dim, N] = size(offspring);
    for i = 1:N
        if rand < params.mutationProbability
            mutation_vector = randn(dim,1) * 0.01;
            offspring(:,i) = offspring(:,i) + mutation_vector;
        end
    end
end

function metrics = calculateMetrics(candidatePose, GTPose)
    pose = reshape(candidatePose, 3, []);
    gt = reshape(GTPose, 3, []);
    errors = sqrt(sum((pose - gt).^2, 1));
    
    metrics.MJPE = mean(errors);
    threshold = 0.1;
    metrics.PCK = sum(errors < threshold) / length(errors);
    metrics.PEA = trapz(sort(errors)); % Area under sorted error curve
end

function visualizePoses(candidatePose, GTPose, titleText)
    pose = reshape(candidatePose, 3, []);
    gt = reshape(GTPose, 3, []);
    plot3(gt(1,:), gt(2,:), gt(3,:), 'go-', 'LineWidth', 2); hold on;
    plot3(pose(1,:), pose(2,:), pose(3,:), 'ro--', 'LineWidth', 2);
    legend('Ground Truth', 'Optimized Pose');
    xlabel('X'); ylabel('Y'); zlabel('Z');
    title(titleText); grid on; axis equal;
end
